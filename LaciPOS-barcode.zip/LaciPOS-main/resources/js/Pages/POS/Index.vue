<script setup>
import AppLayout from '@/Layouts/AppLayout.vue';
import ProductGrid from '@/Components/ProductGrid.vue';
import CartPanel from '@/Components/CartPanel.vue';
import VariantPickerModal from '@/Components/VariantPickerModal.vue';
import PaymentModal from '@/Components/PaymentModal.vue';
import { ref, nextTick, onUnmounted } from 'vue';
import { useCart } from '@/composables/useCart';
import { useToast } from '@/composables/useToast';
import { router } from '@inertiajs/vue3';
import { ShoppingBag, ScanBarcode, X } from 'lucide-vue-next';

const props = defineProps({
    products: Array,
    categories: Array,
    next_order_number: String,
    payment_methods: Array,
});

const { items, addItem, finalTotal, clearCart, getQuantityByProductId, getDiscountedQuantityByProductId, cartDiscountType, cartDiscountValue, cartDiscountNote } = useCart();
const toast = useToast();

const showVariantModal = ref(false);
const selectedProduct = ref(null);

const showPaymentModal = ref(false);
const paymentTotal = ref(0);
const barcodeInput = ref('');
const barcodeMessage = ref('');
const showScanner = ref(false);
const scannerVideo = ref(null);
let scannerStream = null;
let scannerFrame = null;
let scannerDetector = null;
const stopScanner = () => {
    showScanner.value = false;
    if (scannerFrame) cancelAnimationFrame(scannerFrame);
    scannerFrame = null;
    if (scannerStream) scannerStream.getTracks().forEach(track => track.stop());
    scannerStream = null;
    scannerDetector = null;
};
const startScanner = async () => {
    if (!('BarcodeDetector' in window)) {
        barcodeMessage.value = 'Browser ini belum mendukung scan kamera. Gunakan scanner USB atau masukkan barcode pada kolom.';
        return;
    }
    try {
        scannerDetector = new window.BarcodeDetector({ formats: ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128', 'code_39', 'itf', 'qr_code'] });
        scannerStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        showScanner.value = true;
        await nextTick();
        scannerVideo.value.srcObject = scannerStream;
        await scannerVideo.value.play();
        const detect = async () => {
            if (!showScanner.value || !scannerVideo.value || !scannerDetector) return;
            try {
                const codes = await scannerDetector.detect(scannerVideo.value);
                if (codes.length && codes[0].rawValue) {
                    barcodeInput.value = codes[0].rawValue;
                    stopScanner();
                    handleBarcodeSubmit();
                    return;
                }
            } catch (_) {}
            scannerFrame = requestAnimationFrame(detect);
        };
        detect();
    } catch (error) {
        stopScanner();
        barcodeMessage.value = 'Kamera tidak dapat diakses. Izinkan akses kamera atau gunakan scanner USB.';
    }
};
onUnmounted(stopScanner);
const handleBarcodeSubmit = () => {
    const code = barcodeInput.value.trim();
    if (!code) return;
    const product = props.products.find(p => p.barcode && String(p.barcode).toLowerCase() === code.toLowerCase());
    if (!product) {
        barcodeMessage.value = `Barcode "${code}" tidak ditemukan. Pastikan barcode sudah diisi pada data produk.`;
        return;
    }
    barcodeMessage.value = '';
    barcodeInput.value = '';
    handleProductClick(product);
};

// Fly-to-cart animation state
const flyingItems = ref([]);
const cartPanelRef = ref(null);

const triggerFlyAnimation = (event, product) => {
    // Walk up from target to find the product card button
    let trigger = event?.target;
    while (trigger && !trigger.classList.contains('product-card')) {
        trigger = trigger.parentElement;
    }
    if (!trigger) return;

    const fromRect = trigger.getBoundingClientRect();
    const cartEl = document.querySelector('.pos-cart-panel');
    if (!cartEl) return;
    const toRect = cartEl.getBoundingClientRect();

    const id = Date.now() + Math.random();
    const item = {
        id,
        photoUrl: product.photo_url || null,
        name: product.name,
        startX: fromRect.left + fromRect.width / 2,
        startY: fromRect.top + fromRect.height / 2,
        endX: toRect.left + 40,
        endY: toRect.top + 40,
    };

    flyingItems.value.push(item);
    setTimeout(() => {
        flyingItems.value = flyingItems.value.filter(i => i.id !== id);
    }, 700);
};

const handleProductClick = (product, event) => {
    if (product.has_variants) {
        selectedProduct.value = product;
        showVariantModal.value = true;
    } else {
        const added = addToCartDirect(product);
        if (added && event) triggerFlyAnimation(event, product);
    }
};

const addToCartDirect = (product) => {
    const currentQty = getQuantityByProductId(product.id);
    if (currentQty >= product.stock) {
        toast.error(`Stok produk '${product.name}' tidak mencukupi.`);
        return false;
    }

    let discountType = null;
    let discountValue = null;

    if (product.is_discount_active) {
        if (product.discount_quota_remaining !== null) {
            const discountedQtyInCart = getDiscountedQuantityByProductId(product.id);
            if (discountedQtyInCart < product.discount_quota_remaining) {
                discountType = product.discount_type;
                discountValue = product.discount_value;
            } else {
                toast.warning(`Kuota diskon '${product.name}' telah habis. Ditambahkan dengan harga normal.`);
            }
        } else {
            discountType = product.discount_type;
            discountValue = product.discount_value;
        }
    }

    addItem({
        productId: product.id,
        productName: product.name,
        variantLabel: null,
        price: Number(product.price),
        cogs: Number(product.cogs),
        stock: product.stock,
        photoUrl: product.photo_url,
        discountType: discountType,
        discountValue: discountValue,
        discountQuotaRemaining: product.discount_quota_remaining,
    });
    return true;
};

const addToCartFromModal = (data) => {
    const currentQty = getQuantityByProductId(data.product.id);
    if (currentQty >= data.product.stock) {
        toast.error(`Stok produk '${data.product.name}' tidak mencukupi.`);
        return;
    }

    let applyDiscount = false;
    let discountType = null;
    let discountValue = null;

    if (data.product.is_discount_active) {
        if (data.product.discount_quota_remaining !== null) {
            const discountedQtyInCart = getDiscountedQuantityByProductId(data.product.id);
            if (discountedQtyInCart < data.product.discount_quota_remaining) {
                applyDiscount = true;
                discountType = data.product.discount_type;
                discountValue = data.product.discount_value;
            } else {
                toast.warning(`Kuota diskon '${data.product.name}' telah habis. Ditambahkan dengan harga normal.`);
            }
        } else {
            applyDiscount = true;
            discountType = data.product.discount_type;
            discountValue = data.product.discount_value;
        }
    }

    addItem({
        productId: data.product.id,
        productName: data.product.name,
        variantLabel: data.variantLabel,
        price: data.finalPrice,
        cogs: data.finalCogs,
        stock: data.product.stock,
        photoUrl: data.product.photo_url,
        discountType: discountType,
        discountValue: discountValue,
        discountQuotaRemaining: data.product.discount_quota_remaining,
    });
};

const handleCheckout = (total) => {
    paymentTotal.value = total;
    showPaymentModal.value = true;
};

const handleConfirmPayment = (paymentData) => {
    router.post('/orders', {
        ...paymentData,
        items: items.value.map(item => ({
            productId: item.productId,
            productName: item.productName,
            price: item.price,
            cogs: item.cogs,
            quantity: item.quantity,
            variantLabel: item.variantLabel,
            notes: item.notes,
            discount_type: item.discountType,
            discount_value: item.discountValue,
        })),
        discount_type: cartDiscountType.value,
        discount_value: cartDiscountValue.value,
        discount_note: cartDiscountNote.value,
    }, {
        onSuccess: () => {
            clearCart();
            showPaymentModal.value = false;
        },
    });
};
</script>

<template>
    <!-- POS uses full-height layout without extra padding from AppLayout -->
    <AppLayout title="Kasir (POS)">
        <template #header>
            <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between w-full">
                <div>
                    <h1 class="text-lg font-semibold text-[#001e2b]">Kasir (POS)</h1>
                    <p class="text-xs text-[#7c8c9a]">Kelola transaksi penjualan dengan mudah</p>
                </div>
            </div>
        </template>

        <template #default>
            <div class="pos-wrapper">
                <!-- Left Panel: Product Grid -->
                <div class="pos-products-panel">
                    <div class="barcode-tools">
                        <form class="barcode-form" @submit.prevent="handleBarcodeSubmit">
                            <ScanBarcode class="barcode-icon" />
                            <input v-model="barcodeInput" type="text" autocomplete="off" placeholder="Scan / masukkan barcode lalu Enter" aria-label="Barcode produk" />
                            <button type="submit">Tambah</button>
                        </form>
                        <button type="button" class="barcode-camera-button" @click="startScanner">Scan Kamera</button>
                        <p v-if="barcodeMessage" class="barcode-message">{{ barcodeMessage }}</p>
                    </div>
                    <ProductGrid
                        :products="products"
                        :categories="categories"
                        :next-order-number="next_order_number"
                        @add-to-cart="handleProductClick"
                    />
                </div>

                <!-- Right Panel: Cart -->
                <div class="pos-cart-panel">
                    <CartPanel @checkout="handleCheckout" />
                </div>
            </div>

            <!-- Fly-to-Cart Ghost Elements (rendered at body level via fixed positioning) -->
            <Teleport to="body">
                <div
                    v-for="item in flyingItems"
                    :key="item.id"
                    class="fly-ghost"
                    :style="{
                        '--from-x': item.startX + 'px',
                        '--from-y': item.startY + 'px',
                        '--to-x': item.endX + 'px',
                        '--to-y': item.endY + 'px',
                    }"
                >
                    <img v-if="item.photoUrl" :src="item.photoUrl" :alt="item.name" class="fly-ghost__img" />
                    <div v-else class="fly-ghost__fallback">
                        <ShoppingBag class="fly-ghost__icon" />
                    </div>
                </div>
            </Teleport>

            <VariantPickerModal
                :open="showVariantModal"
                :product="selectedProduct"
                @close="showVariantModal = false"
                @add-to-cart="addToCartFromModal"
            />

            <div v-if="showScanner" class="scanner-overlay" @click.self="stopScanner">
                <div class="scanner-dialog">
                    <div class="scanner-heading"><h2>Scan Barcode</h2><button type="button" @click="stopScanner" aria-label="Tutup scanner"><X /></button></div>
                    <video ref="scannerVideo" playsinline muted class="scanner-video"></video>
                    <p>Arahkan barcode produk ke kamera.</p>
                </div>
            </div>

            <PaymentModal
                :open="showPaymentModal"
                :total="paymentTotal"
                :payment-methods="payment_methods"
                @close="showPaymentModal = false"
                @confirm-payment="handleConfirmPayment"
            />
        </template>
    </AppLayout>
</template>

<style scoped>
.barcode-tools { display: flex; gap: 8px; flex-wrap: wrap; padding: 0 0 10px; }
.barcode-form { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 220px; background: #fff; border: 1px solid #c1ccd6; border-radius: 10px; padding: 5px 7px 5px 12px; }
.barcode-icon { width: 18px; height: 18px; color: #00684a; flex-shrink: 0; }
.barcode-form input { flex: 1; min-width: 0; outline: none; border: 0; font-size: 13px; background: transparent; color: #001e2b; }
.barcode-form button, .barcode-camera-button { border: 0; border-radius: 7px; padding: 8px 12px; font-size: 12px; font-weight: 600; cursor: pointer; background: #001e2b; color: white; }
.barcode-camera-button { background: #00684a; }
.barcode-message { flex-basis: 100%; margin: 0; font-size: 12px; color: #b42318; }
.scanner-overlay { position: fixed; inset: 0; z-index: 1000; display: flex; align-items: center; justify-content: center; padding: 20px; background: rgba(0, 20, 28, .72); }
.scanner-dialog { width: min(560px, 100%); padding: 18px; background: white; border-radius: 16px; color: #001e2b; }
.scanner-heading { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; font-weight: 700; }
.scanner-heading button { display: flex; padding: 5px; background: transparent; border: 0; cursor: pointer; }
.scanner-video { width: 100%; max-height: 60vh; object-fit: cover; border-radius: 10px; background: #111; }
.scanner-dialog p { margin-top: 10px; font-size: 13px; color: #5c6c7a; }
.pos-wrapper {
    display: flex;
    gap: 20px;
    /* Adjusted for AppLayout padding and the new header height */
    height: calc(100vh - 225px);
    min-height: 0;
}

.pos-products-panel {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;
}

.pos-cart-panel {
    width: 360px;
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    min-height: 0;
}
</style>

<style>
/* Fly-to-cart animation — must NOT be scoped so Teleport can access */
.fly-ghost {
    position: fixed;
    width: 48px;
    height: 48px;
    border-radius: 12px;
    overflow: hidden;
    pointer-events: none;
    z-index: 9999;
    box-shadow: 0 8px 24px rgba(0, 30, 43, 0.25);
    border: 2px solid #00ed64;
    animation: fly-to-cart 0.65s cubic-bezier(0.25, 0.46, 0.45, 0.94) forwards;
}

.fly-ghost__img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.fly-ghost__fallback {
    width: 100%;
    height: 100%;
    background: #001e2b;
    display: flex;
    align-items: center;
    justify-content: center;
}

.fly-ghost__icon {
    width: 22px;
    height: 22px;
    color: #00ed64;
}

@keyframes fly-to-cart {
    0% {
        left: calc(var(--from-x) - 24px);
        top: calc(var(--from-y) - 24px);
        opacity: 1;
        transform: scale(1);
    }
    60% {
        opacity: 1;
        transform: scale(0.85);
    }
    100% {
        left: calc(var(--to-x) - 24px);
        top: calc(var(--to-y) - 24px);
        opacity: 0;
        transform: scale(0.4);
    }
}
</style>
