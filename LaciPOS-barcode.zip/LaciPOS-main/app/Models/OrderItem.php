<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Concerns\HasUlids;
use Illuminate\Database\Eloquent\Model;

class OrderItem extends Model
{
    use HasUlids;

    public $timestamps = false;

    protected $fillable = [
        'product_id', 'product_name_snapshot', 'variant_label',
        'quantity', 'notes',
        'snapshot_discount_type', 'snapshot_discount_value',
    ];

    protected function casts(): array
    {
        return [
            'snapshot_cogs' => 'decimal:2',
            'snapshot_price' => 'decimal:2',
            'subtotal' => 'decimal:2',
            'quantity' => 'integer',
            'snapshot_discount_value' => 'decimal:2',
            'snapshot_discount_amount' => 'decimal:2',
        ];
    }

    public function order(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    public function product(): \Illuminate\Database\Eloquent\Relations\BelongsTo
    {
        return $this->belongsTo(Product::class);
    }
}
